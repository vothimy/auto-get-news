<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CatChild extends Model
{
    protected $table = 'category_child';
    protected $primaryKey = 'id';
}
