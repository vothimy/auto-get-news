<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RSS extends Model
{
    protected $table = 'linkrss';
    protected $primaryKey = 'id';
}
